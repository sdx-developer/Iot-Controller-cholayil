var localHoster	 = "http://127.0.0.1:8887";
var dsTypesArray = ["ws","db","xls","external"];
var dsTypeDelim  = "-ds-";

//For Data Widgets
var mulSelType   = "multi-select"; //CheckBox
var sinSelType   = "single-select"; //RadioButton
var defaultIDCol = "IDColumn";

var dc_type 	 = "DataCollector";
var act_type 	 = "Activity";
var qf_type 	 = "QueueFactory";


var URN_workflow 		= "urn:com:servicedx:model:WorkFlow";
var URN_schedule 		= "urn:com:servicedx:model:Schedule";
var URN_dataColl 		= "urn:com:servicedx:model:DataConnector";
var URN_activity 		= "urn:com:servicedx:model:Activity";
var URN_qfactory 		= "urn:com:servicedx:model:QueueFactory";
var URN_user	 		= "urn:com:servicedx:model:User";
var URN_userrole 		= "urn:com:servicedx:model:UserRole";
var URN_department 		= "urn:com:servicedx:model:Department";
var URN_designation		= "urn:com:servicedx:model:Designation";
var URN_dbConnector 	= "urn:com:servicedx:model:DatabaseConnector";
var URN_wsConnector 	= "urn:com:servicedx:model:WebServiceConnector";
var URN_xlsConnector 	= "urn:com:servicedx:model:SpreadSheetConnector";
var URN_appConnector	= "urn:com:servicedx:model:ExternalAppConnector";
var URN_slotImpl		= "urn:com:servicedx:model:SlotImpl";
var URN_timeBound		= "urn:com:servicedx:model:TimeBound";
var URN_approvalProc	= "urn:com:servicedx:model:ApprovalProcess";




