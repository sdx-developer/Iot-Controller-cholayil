
public class ConfigInsert {
	


}
