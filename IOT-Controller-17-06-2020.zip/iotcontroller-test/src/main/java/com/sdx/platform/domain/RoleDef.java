package com.sdx.platform.domain;

public enum RoleDef {
	
	SUPER_ADMIN, ADMIN, SUPERVISOR, USER, CONTRACTOR, CUSTOM;

}
