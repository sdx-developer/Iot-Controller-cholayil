package com.sdx.platform.domain;

public class UserRole {
	
	private String _id;
	private RoleDef roleDef;

}
